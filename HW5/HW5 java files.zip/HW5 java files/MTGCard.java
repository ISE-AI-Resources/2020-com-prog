
public class MTGCard {
	String name;
	String cost;
	String text;

	public MTGCard(String name, String cost, String text) {
		super();
		this.name = name;
		this.cost = cost;
		this.text = text;
	}

	public boolean equals(Object o) {
		MTGCard o2 = (MTGCard) o;
		return (this.name == o2.name && this.cost == o2.cost && this.text == o2.text);


	}

}
