package hw12;

public class HistogramDataDisplay extends DataDisplay{
	public HistogramDataDisplay(String name, Data subject) {
		super(name,subject);
	}
	@Override
	public void update() {
		int[] nums = super.getContent();
		System.out.println(getClass() + ": " + name);
		for(int num: nums) {
			System.out.print(num + "\t");
			for(int i = 0; i < num; i++) System.out.print("*");
			System.out.println();
		}
	}
}
