package hw12;
import java.util.Arrays;
public class BorderDataDisplay extends DataDisplay{
	public BorderDataDisplay(String name, Data subject) {
		super(name,subject);
	}
	@Override
	public void update() {
		System.out.println("*********************************");
		System.out.println(getClass() + ": " + name);
		System.out.println("\t" + Arrays.toString(super.getContent()));
		System.out.println("*********************************");
	}
}
