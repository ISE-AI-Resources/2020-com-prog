package hw12;

public class A {
	private int dataA;
	public static boolean debug;

	public A(int a) {
		if (A.debug) {
			System.out.println("Class A is called!");
		}
		this.dataA = a;
	}

	public void f() {
		System.out.println("f() of Class A is being called!");
	}
	public int g() {
		return dataA + 1;
	}
}
