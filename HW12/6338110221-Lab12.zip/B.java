package hw12;

public class B extends A{
	private int dataB;
	public B(int a, int b) {
		super(a);
		dataB = b;
		if(A.debug) {
			System.out.println("Class B is called!");
		}
	}
	public void f() {
		System.out.println("f() of Class B is being called!");
	}
	public int g() {
		return 2*super.g() + dataB;
	}
}
