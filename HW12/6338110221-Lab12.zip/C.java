package hw12;

public class C extends B{
	private int dataC;
	public C(int a, int b, int c) {
		super(a,b);
		dataC = c;
		if(A.debug) {
			System.out.println("Class C is called!");
		}
	}
	public void f() {
		System.out.println("f() of Class C is being called!");
	}
	public int g() {
		return super.g() - 10 + dataC *3;
	}
}
