package hw12;

public class MaxDataDisplay extends DataDisplay{
	private int maxValue = Integer.MIN_VALUE;
	public MaxDataDisplay(String name, Data subject) {
		super(name,subject);
	}
	@Override
	public void update() {
		int[] nums = super.getContent();
		for(int num: nums) {
			if(num > maxValue) maxValue = num;
		}
		System.out.println(getClass() + ": " + name);
		System.out.println("\t" + maxValue);
	}
	
}
