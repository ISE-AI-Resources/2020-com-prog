package hw11;

public class WitchGame {

	public static void main(String[] args) {
		Witch witch1 = new Witch();
		Witch witch2 = new Witch("Akko", "Luna Nova", 25);
		System.out.println("====================");
		System.out.println("Printing 2 witches");
		System.out.println("====================");
		System.out.println(witch1.toString());
		System.out.println(witch2.toString());
		System.out.println("====================");
		witch1.setName("Hermione Granger");
		witch1.setSchool("Hogwarts");
		witch1.setMagicPower(85);
		System.out.println("====================");
		System.out.println("Printing comparisons");
		switch(witch1.compareTo(witch2)) {
			case 1:
				System.out.println(witch1.toString() + " has higher magic power");
				break;
			case -1:
				System.out.println(witch2.toString() + " has higher magic power");
				break;
			default:
				System.out.println(witch1.getName() + " and " + witch2.getName() + " have the same magic power");
		}
		Witch witch3 = new Witch(witch1);
		witch3.levelUp(80);
		switch(witch2.compareTo(witch3)) {
		case 1:
			System.out.println(witch2.toString() + " has higher magic power");
			break;
		case -1:
			System.out.println(witch3.toString() + " has higher magic power");
			break;
		default:
			System.out.println(witch2.getName() + " and " + witch3.getName() + " have the same magic power");
		}
		System.out.println("====================");
		System.out.println("Now, printing all witches.");
		System.out.println("====================");
		System.out.println(witch1.toString());
		System.out.println(witch2.toString());
		System.out.println(witch3.toString());
		System.out.println("====================");
		System.out.println("Now, printing total number of witches.");
		System.out.println("====================");
		System.out.println(Witch.getTotalWitches());
	}

}
