package hw11;

public class Witch {
	private static int totalWitches = 0;
	private String name;
	private String school;
	private int magicPower;
	public Witch() {
		this("no one", "unknown school", 10);
	}
	public Witch(Witch b) {
		this(b.name,b.school,b.magicPower);
	}
	public Witch(String name, String school, int magicPower) {
		totalWitches++;
		this.name = name;
		this.school = school;
		this.magicPower = magicPower;
	}
	public static int getTotalWitches() {
		return totalWitches;
	}
	public static void setTotalWitches(int totalWitches) {
		if(totalWitches < 0) totalWitches = 0;
		Witch.totalWitches = totalWitches;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public int getMagicPower() {
		return magicPower;
	}
	public void setMagicPower(int magicPower) {
		if(magicPower > 100) magicPower = 100;
		if(magicPower < 0) magicPower = 0;
		this.magicPower = magicPower;
	}
	public String toString() {
		return "Witch name: " + this.name + ", School: " + this.school + ", Magic Power: " + this.magicPower;
	}
	public int compareTo(Witch b) {
		if(this.magicPower > b.magicPower) return 1;
		else if(this.magicPower == b.magicPower) return 0;
		return -1;
	}
	public void levelUp(int increase) {
		if(increase > 0) {
			this.magicPower += increase;
			if(this.magicPower > 100) this.magicPower = 100;
		}
	}
	
}
